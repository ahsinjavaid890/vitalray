

 
<?php $__env->startSection('meta-tags'); ?>
<title>Dashboard</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-content'); ?>
<div class="content-page">
    <div class="content">
        
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                            <!-- <li class="breadcrumb-item active">Projects</li> -->
                        </ol>
                    </div>
                    <h4 class="page-title">Dashboard</h4>
                </div>
            </div>
        </div>     
        <!-- end page title --> 

        <div class="row">
            
        </div>
        <!-- end row-->


    
        <!-- end row-->
    </div> <!-- End Content -->

</div> <!-- content-page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vitalray\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>