
<?php $__env->startSection('meta-tags'); ?>
<title>Update Freequency</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-content'); ?>

<?php echo $__env->make('admin.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://cdn.ckeditor.com/4.19.0/standard/ckeditor.js"></script>

<div class="content-page">
    <div class="content">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/freequency/all')); ?>">All Freequency</a></li>
                            <li class="breadcrumb-item active">Add New Freequency</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Add New Freequency</h4>
                </div>
            </div>
        </div>     
        <!-- end page title --> 

        <!-- end page title -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                            <form enctype="multipart/form-data" method="POST" action="<?php echo e(url('admin/freequency/updatefreequency')); ?>">
                                <?php echo e(csrf_field()); ?>

                            <input type="hidden" value="<?php echo e($data->id); ?>" name="id">
                            <div class="modal-body">
                                <div class="form-group">
                                    <label>Freequency Tittle</label>
                                    <input type="text" value="<?php echo e($data->name); ?>" required name="name" placeholder="Freequency Tittle" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label class="lable-control">Freequency File Upload</label>
                                    <input type="file" class="form-control" name="freequency">
                                </div>
                                <div class="form-group">
                                    <label class="lable-control">Image</label>
                                    <input type="file" class="form-control" name="image">
                                </div>
                                <div class="form-group">
                                    <label>Used vibration</label>
                                    <input type="text" value="<?php echo e($data->vibration); ?>" name="vibration" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label>Used Emitter</label>
                                    <input type="text" value="<?php echo e($data->emitter); ?>" name="emitter" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label class="lable-control">Description</label>
                                    <textarea class="form-control" name="description"><?php echo e($data->description); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label class="lable-control">Featured</label>
                                    <select class="form-control" name="show_on_homepage">
                                        <option value="">Select</option>
                                        <option <?php if($data->show_on_homepage == 'yes'): ?> selected <?php endif; ?> value="yes">Yes</option>
                                        <option <?php if($data->show_on_homepage == 'no'): ?> selected <?php endif; ?> value="no">No</option>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Update Freequency</button>
                            </div>
                            </form>
                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col -->
        </div>
        
    </div> <!-- End Content -->

</div> <!-- content-page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vitalray\resources\views/admin/freequency/edit.blade.php ENDPATH**/ ?>