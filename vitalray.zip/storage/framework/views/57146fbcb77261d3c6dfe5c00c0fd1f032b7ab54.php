
<?php $__env->startSection('meta-tags'); ?>
<title>All Products</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-content'); ?>
<div class="container-fluid">
                        
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">All Products</li>
                    </ol>
                </div>
                <h4 class="page-title">All Products</h4>
            </div>
        </div>
    </div>     
    <!-- end page title --> 

    <!-- end row-->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body table-responsive">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Product Image</th>
                                <th>Product Name</th>
                                <th>Product Price</th>
                                <th>Document</th>
                                <th>Action</th>
                            </tr>
                        </thead>                    
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><img src="<?php echo e(url('public/images')); ?>/<?php echo e($r->image); ?>" width="120" height="120" class="img-thumbnail"></th>
                                <th><?php echo e($r->name); ?></th>
                                <td>$<?php echo e($r->price); ?></td>
                                <td>
                                    <a href="<?php echo e(url('public/images')); ?>/<?php echo e($r->document); ?>" class="btn btn-primary" download="true">PDF Document</a>
                                </td>
                                <td>
                                    <a href="<?php echo e(url('admin/products/edit')); ?>/<?php echo e($r->id); ?>" class="btn btn-primary">Edit</a>
                                    <a data-toggle="modal" data-target="#myModal<?php echo e($r->id); ?>" href="javascript:void(0)" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                            <!-- Modal -->
                            <div id="myModal<?php echo e($r->id); ?>" class="modal fade" role="dialog">
                              <div class="modal-dialog">
                                <form method="POST" action="<?php echo e(url('admin/products/delete')); ?>">
                                    <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($r->id); ?>" name="id">
                                <!-- Modal content-->
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h4 class="modal-title">Delete Product</h4>
                                  </div>
                                  <div class="modal-body">
                                    Are You Sure You Want to Delete This Product?
                                  </div>
                                  <div class="modal-footer">
                                    <button type="submit" class="btn btn-success">Yes</button>
                                  </div>
                                </div>
                                </form>
                              </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>  
                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row -->        
    
</div> <!-- container -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vitalray\resources\views/admin/products/all.blade.php ENDPATH**/ ?>