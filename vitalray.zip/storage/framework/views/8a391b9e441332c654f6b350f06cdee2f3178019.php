
<?php $__env->startSection('meta-tags'); ?>
<title>Home</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="gradient-form background-radial-gradient">
    <!-- overlay -->
    <div id="sidebar-overlay" class="overlay w-100 vh-100 position-fixed d-none"></div>

    <!-- sidebar -->
    <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-md-9 col-lg-10 ml-md-auto px-0 ms-md-auto">
      <!-- main content -->
      <main class="p-4 min-vh-100" style="overflow-y:auto !important; height: 100vh;">
        <div class="container">
          <div class="row section-header">
            <div class="col-md-12">
              <h3>Featured Lists</h3>
              <p>Find our featured lists for you</p>
            </div>
          </div>
          <div class="row mb-3">
            <?php $__currentLoopData = DB::table('freequencies')->where('show_on_homepage' , 'yes')->limit(6)->orderby('id' , 'desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-2">
                <div class="card bg-dark text-white card-featured">
                  <img class="card-img" src="<?php echo e(url('public/images')); ?>/<?php echo e($r->image); ?>" alt="Card image">
                  <div class="card-img-overlay">
                    <a href="<?php echo e(url('profile/frequency')); ?>/<?php echo e($r->id); ?>/<?php echo e($r->slug); ?>"><img class="play-icon" src="<?php echo e(asset('public/front/media/play-icon.png')); ?>" alt="Play icon"></a>
                    <p class="card-text"><?php echo e($r->vibration); ?></p>
                    <h5 class="card-title"><a href="<?php echo e(url('profile/frequency')); ?>/<?php echo e($r->id); ?>/<?php echo e($r->slug); ?>"><?php echo e($r->name); ?></a></h5>
                  </div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row section-header">
              <div class="col-md-12">
                <h3>Other Lists</h3>
                <p>Find the relavant lists</p>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="row">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                      <a href="<?php echo e(url('profile/frequency')); ?>/<?php echo e($r->id); ?>/<?php echo e($r->slug); ?>" class="single-frequency">
                        <div class="card mb-2">
                          <div class="card-body p-2">
                            <div class="d-flex align-items-center">
                              <div class="p-2 flex-grow-1">
                                <div class="d-flex flex-row">
                                  <div class="p-2">
                                    <img class="img-preview" src="<?php echo e(url('public/images')); ?>/<?php echo e($r->image); ?>">
                                  </div>
                                  <div class="p-2">
                                    <h4><?php echo e($r->name); ?></h4>
                                    <small><?php echo e($r->vibration); ?></small>
                                  </div>
                                </div>
                              </div>
                              <div class="p-2">
                                <img src="<?php echo e(asset('public/front/media/play-gradient.svg')); ?>" width="50">
                              </div>
                            </div>
                          </div>
                        </div>
                      </a>
                    </div>
                    
                    <!-- <div style="background-color: #ddd;padding: 10px;border-radius: 10px;color: black;" class="row mb-3">
                        <div class="col-md-2">
                            <a href="<?php echo e(url('profile/frequency')); ?>/<?php echo e($r->id); ?>/<?php echo e($r->slug); ?>">
                                <img class="img-thumbnail" width="100" src="<?php echo e(url('public/images')); ?>/<?php echo e($r->image); ?>">
                            </a>
                        </div>
                        <div class="col-md-10">
                            <div class="mp3-player">
                              <audio class="form-control" controls>
                                <source src="<?php echo e(url('public/images')); ?>/<?php echo e($r->freequency); ?>" type="audio/mpeg">
                                Your browser does not support the audio element.
                              </audio>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label>Name</label>
                            <div><b><?php echo e($r->name); ?></b></div>
                        </div>
                        <div class="col-md-4">
                            <label>vibration</label>
                            <div><b><?php echo e($r->vibration); ?></b></div>
                        </div>
                        <div class="col-md-4">
                            <label>emitter</label>
                            <div><b><?php echo e($r->emitter); ?></b></div>
                        </div>
                        <div class="col-md-12">
                            <label>description</label>
                            <div><b><?php echo e($r->description); ?></b></div>
                        </div>
                    </div> -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
              </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-4">
                </div>
                <div class="col-md-4">
                    <?php echo $data->links('admin.pagination'); ?>

                </div> 
                <div class="col-md-4">
                </div>                       
            </div>
          </div>
      </main>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.front-app-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vitalray\resources\views/frontend/user/home.blade.php ENDPATH**/ ?>