


<?php $__env->startSection('meta-tags'); ?>
<title>All Pages</title>
<script src="<?php echo e(asset('admin/assets/js/driver.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-content'); ?>

<?php echo $__env->make('admin.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <!-- start page title -->
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Pages</li>
                    </ol>
                </div>
                <h4 class="page-title">Pages</h4>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs nav-bordered mb-3">
        <li class="nav-item">
            <a href="<?php echo e(url('admin/pages/allpages')); ?>"  class="nav-link <?php if($viewstatus == 'all'): ?> active <?php endif; ?>">
                <i class="mdi mdi-home-variant d-md-none d-block"></i>
                <span class="d-none d-md-block">All<span style="margin-left: 10px;" class="badge badge-pill badge-info"><?php echo e(DB::table('dynamicpages')->where('delete_status' , 'Active')->count()); ?></span></span>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(url('admin/pages/allpages/published')); ?>"  class="nav-link <?php if($viewstatus == 'published'): ?> active <?php endif; ?>">
                <i class="mdi mdi-account-circle d-md-none d-block"></i>
                <span class="d-none d-md-block">Published<span style="margin-left: 10px;" class="badge badge-pill badge-success"><?php echo e(DB::table('dynamicpages')->where('visible_status' , 'Published')->where('delete_status' , 'Active')->count()); ?></span></span>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(url('admin/pages/allpages/notpublished')); ?>"  class="nav-link <?php if($viewstatus == 'notpublished'): ?> active <?php endif; ?>">
                <i class="mdi mdi-settings-outline d-md-none d-block"></i>
                <span class="d-none d-md-block">Not Published<span style="margin-left: 10px;" class="badge badge-pill badge-warning"><?php echo e(DB::table('dynamicpages')->where('visible_status' , 'Not Published')->where('delete_status' , 'Active')->count()); ?></span></span>
            </a>
        </li>
    </ul> 
    <!-- end page title --> 
    <!-- end page title -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead  class="thead-light">
                                <tr>
                                    <th>Page Name</th>
                                    <th>Visible on Footer</th>
                                    <th>Visible Order</th>
                                    <th>Visible Status</th>
                                    <th>Created At</th>
                                    <th style="width: 120px;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($r->name); ?></td>
                                    <td><span style="font-size: 15px;" class="badge badge-pill <?php if($r->show_on_footer == 'Yes'): ?> badge-success <?php else: ?> badge-danger <?php endif; ?>"><?php echo e($r->show_on_footer); ?></span></td>
                                    <td><?php echo e($r->visible_order); ?></td>
                                    <td><div class="badge badge-pill <?php if($r->visible_status == 'Published'): ?> badge-success <?php endif; ?> <?php if($r->visible_status == 'Trash'): ?> badge-danger <?php endif; ?> <?php if($r->visible_status == 'Not Published'): ?> badge-warning <?php endif; ?>" style="font-size: 15px;"><?php echo e($r->visible_status); ?></div></td>
                                    <td><?php echo e(date('d M Y, h:s a ', strtotime($r->created_at))); ?></td>
                                    <td class="table-action text-center">
                                        <a href="<?php echo e(url('admin/pages/edit')); ?>/<?php echo e($r->id); ?>" class="action-icon" title="Edit Category"> <i class="mdi mdi-pencil"></i></a>
                                        <a onclick="return confirm('Are You Sure You want to Delete This')" href="<?php echo e(url('admin/pages/deletepage')); ?>/<?php echo e($r->id); ?>" class="action-icon" title="Delte Category"> <i class="mdi mdi-delete"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row -->  
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vitalray\resources\views/admin/pages/allpages.blade.php ENDPATH**/ ?>