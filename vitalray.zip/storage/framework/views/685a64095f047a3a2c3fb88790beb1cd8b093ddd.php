
<?php $__env->startSection('title'); ?>
<title>Sign In</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
    body{
        height: 100vh !important;
    background-color: hsl(218, 41%, 15%);
    background-image: radial-gradient(650px circle at 0% 0%, hsl(218, 41%, 35%) 15%, hsl(218, 41%, 30%) 35%, hsl(218, 41%, 20%) 75%, hsl(218, 41%, 19%) 80%, transparent 100%), radial-gradient(1250px circle at 100% 100%, hsl(218, 41%, 45%) 15%, hsl(218, 41%, 30%) 35%, hsl(218, 41%, 20%) 75%, hsl(218, 41%, 19%) 80%, transparent 100%);

    }
    .card-header{
        border-bottom: 1px solid #ddd;
    }
</style>
<div class="container ">
    <div class="row justify-content-center">
        <div class="col-lg-5">
            <div class="card" style="margin-top: 100px;">

                <!-- Logo -->
                <div class="card-header pt-4 pb-4 text-center">
                    <a href="<?php echo e(url('')); ?>">
                        <img class="mb-2" src="<?php echo e(asset('public/front/media/logo.png')); ?>" style="width: 105px;" alt="logo">
                    </a>
                </div>

                <div class="card-body p-4">
                    
                    <div class="text-center w-75 m-auto">
                        <h4 class="text-dark-50 text-center mt-0 font-weight-bold">Admin Login</h4>
                        <p class="text-muted mb-4">Enter your email address and password to access admin panel.</p>
                    </div>
                    <?php if(session()->has('error')): ?>
                        <div style="text-align: center;color: red;" id="result"><?php echo e(session()->get('error')); ?></div>
                    <?php endif; ?>
                    <div class="text-center">
                        <div id="loader" class=""></div>
                    </div>
                    <form action="<?php echo e(route('adminlogin')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="emailaddress">Email address</label>
                        <!-- <input value="<?php if(session()->has('email')): ?><?php echo e(session()->get('email')); ?>  <?php endif; ?>" class="form-control" type="email" name="email" required="" placeholder="Enter your email"> -->
                        <input type="email"  name="email" class="form-control">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <!-- <a href="<?php echo e(url('forgot-password')); ?>" class="text-muted float-right"><small>Forgot your password?</small></a> -->
                        <label for="password">Password</label>
                        <div class="input-group input-group-merge">
                            <input  type="password" name="password" class="form-control" placeholder="Enter your password">
                            
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <a href="<?php echo e(url('forgot-password')); ?>">Forgot Password</a>
                    <br> <br>
                    <div class="form-group mb-0 text-center">
                        <button class="btn btn-primary btn-block" href="index.php" type="submit"> Log In </button>
                    </div>
                </form>
                </div> <!-- end card-body -->
            </div>
            <!-- end card -->


        </div> <!-- end col -->
    </div>
    <!-- end row -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.authlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vitalray\resources\views/auth/adminlogin.blade.php ENDPATH**/ ?>