@extends('admin.layouts.app')

 
@section('meta-tags')
<title>Dashboard</title>
@endsection


@section('admin-content')
<div class="content-page">
    <div class="content">
        
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                            <!-- <li class="breadcrumb-item active">Projects</li> -->
                        </ol>
                    </div>
                    <h4 class="page-title">Dashboard</h4>
                </div>
            </div>
        </div>     
        <!-- end page title --> 

        <div class="row">
            
        </div>
        <!-- end row-->


    
        <!-- end row-->
    </div> <!-- End Content -->

</div> <!-- content-page -->
@endsection